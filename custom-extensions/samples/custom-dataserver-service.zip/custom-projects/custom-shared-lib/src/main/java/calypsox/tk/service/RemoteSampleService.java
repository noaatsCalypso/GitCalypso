package calypsox.tk.service;

public interface RemoteSampleService {
	public static final String LOG_CATEGORY = "SampleService";
	
	/**
	 * Write a log message in the dataserver log.  Can be used to verify that the dataserver is responding to
	 * client requests.
	 * @param message - Message which should be printed in the log
	 */
	public void writeLogMessage(String message);
}
