package calypsox.tk.service;

public interface LocalSampleService extends RemoteSampleService {

}
