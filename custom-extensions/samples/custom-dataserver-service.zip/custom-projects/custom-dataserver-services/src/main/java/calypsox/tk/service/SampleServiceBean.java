package calypsox.tk.service;

import com.calypso.tk.core.Log;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

@Stateless(name="calypsox.tk.service.RemoteSampleService")
@Remote(RemoteSampleService.class)
@Local(LocalSampleService.class)
@TransactionManagement(TransactionManagementType.CONTAINER)
public class SampleServiceBean implements RemoteSampleService,LocalSampleService {

	@Override
	public void writeLogMessage(String message) {
		Log.system(LOG_CATEGORY, message);
	}
	
}
