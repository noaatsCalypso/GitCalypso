package calypsox.apps.startup;

import calypsox.tk.service.RemoteSampleService;
import com.calypso.tk.core.Log;
import com.calypso.tk.service.DSConnection;
import com.calypso.tk.util.ConnectException;
import com.calypso.tk.util.ConnectionUtil;

public class LoggingClient {
	private static final String LOG_CATEGORY = LoggingClient.class.getSimpleName();

	public static void main(String[] args) {
		DSConnection ds = null;
		try {
			Log.system(LOG_CATEGORY,"Connecting to dataserver");

			ds = ConnectionUtil.connect(args, "LoggingClient");
			
			Log.system(LOG_CATEGORY,"Obtaining remote service from dataserver");

			RemoteSampleService sampleService = ds.getRemoteService(RemoteSampleService.class);
			
			Log.system(LOG_CATEGORY,"Sending message to server");
			
			sampleService.writeLogMessage("My Message");
			
			Log.system(LOG_CATEGORY,"Remote call has been successfully performed");
			
		} catch(ConnectException ex) {
			Log.error(LOG_CATEGORY,"Unable to connect to dataserver", ex);
		} finally {
			if(ds != null) {
				ConnectionUtil.shutdown();
			}
		}

	}

}
