package calypsox.testservices.catt.stepexecutor;
import java.util.List;

import com.calypso.testservices.catt.stepdefinition.entity.TestScriptStepParameterConstants;
import com.calypso.tk.service.DSConnection;
import com.google.common.collect.Lists;
//below classes are moved from calypsox to com.calypso package.
import com.calypso.testservices.catt.context.ScriptExecutionContext;
import com.calypso.testservices.catt.entity.infrastructure.script.TestScriptStep;
import com.calypso.testservices.catt.stepexecutor.AbstractTestScriptStepExecutor;
import com.calypso.testservices.catt.stepexecutor.TestExecutionException;

/**
 * Sample Custom Test Step Executor
 *Performs custom operation on a trade
 */
public class CustomStepTestScriptStepExecutor extends
		AbstractTestScriptStepExecutor {
	/**
	 * Returns all used step parameters names
	 * @return
	 */
	public List<String> getOwnKnownParameters() {
		return MY_KNOWN_PARAMETERS; 
	}
	
	//Step parameters
	private static final List<String> MY_KNOWN_PARAMETERS = Lists.newArrayList( 	TestScriptStepParameterConstants.ATTR_DS, 
																				TestScriptStepParameterConstants.ATTR_TRADE_ID,
																				TestScriptStepParameterConstants.ATTR_OUTPUT_TRADE
																				); 
/**
 * Execution logic for the step.
 */
	@Override
	protected boolean executeInternal(TestScriptStep step,
			ScriptExecutionContext ctx, List<String> messages)
			throws TestExecutionException {
		//Perform the step functionality here
		
		//Get the input parameter
		String tradeReference = getAttributeValue(TestScriptStepParameterConstants.ATTR_TRADE_ID, ctx);
		
		//Get the DSConnectin
		DSConnection dsConnection = (DSConnection) ctx.getValue(getKeyForDSConnection());
		
		//Perform some custom operation
		//......
		//.....
		
		//add execution messages
		messages.add("Completed Custom operation on trade " + tradeReference);
		
		return true; //Return true for SUCCESS of the step
		//return false; //Return false if the step should fail

	}

}
