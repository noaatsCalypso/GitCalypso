package calypsox.testservices.catt.stepdefinition.impl;
import java.util.Map;

import com.calypso.testservices.catt.stepdefinition.TestScriptStepDefinitionLibraryCustomizer;
import com.calypso.testservices.catt.stepdefinition.entity.TestScriptStepDefinition;

/**
 * Register the Custom Steps here
 *
 */
public class CustomTestScriptStepDefinitionLibraryCustomizer implements
		TestScriptStepDefinitionLibraryCustomizer {

	@Override
	public void registerCustomTestScriptStepDefinition(
			Map<String, TestScriptStepDefinition> LIB) {
		//Add the name of the step and its definition class
		LIB.put("CustomStep",new CustomStepTestStepDefinition());
	}

}
