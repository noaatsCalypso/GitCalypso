package calypsox.testservices.catt.stepdefinition.impl;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.calypso.testservices.catt.stepdefinition.entity.TestScriptStepParameter;
import com.calypso.testservices.catt.stepdefinition.entity.TestScriptStepParameterConstants;
import com.calypso.testservices.catt.stepdefinition.entity.TestScriptStepTemplate;
import com.calypso.testservices.catt.stepdefinition.impl.AbstractTestScriptStepDefinition;

/**
 * Step definition class defines the step parameters
 *
 */
public class CustomStepTestStepDefinition extends
		AbstractTestScriptStepDefinition {
	
	//Builds the Step Template with the Step description and the parameters
	@Override
	public TestScriptStepTemplate buildTestScriptStepTemplate() {
	if(tempalte == null){
	tempalte = new TestScriptStepTemplate("CustomStep","Perform custom operation on a trade", getTestScriptStepParameter());
	}
	return tempalte;
	}
/**
 * Returns all parameters and their description.
 * @return
 */
	@Override
	public List<TestScriptStepParameter> getTestScriptStepParameter() {
	if(parameters == null) {
	parameters = new ArrayList<TestScriptStepParameter>();
	parameters.add(new TestScriptStepParameter(TestScriptStepParameterConstants.PRAMETER_ATTR_DS,TestScriptStepParameterConstants.PRAMETER_ATTR_DS,true,"DS_CON",true,"Technical value normal by default DS_CON. The value is used to reference the valid Connection to Calypso.",0));
	parameters.add(new TestScriptStepParameter(TestScriptStepParameterConstants.PRAMETER_ATTR_TRADE_ID,TestScriptStepParameterConstants.PRAMETER_ATTR_TRADE_ID,true,"$VAR_TRADE_ID$",true,"Trade ID or variable content refenced with $xxxxx$ or #xxxxx# Syntax",0));
	parameters.add(new TestScriptStepParameter(TestScriptStepParameterConstants.PRAMETER_ATTR_OUTPUT_TRADE,TestScriptStepParameterConstants.PRAMETER_ATTR_OUTPUT_TRADE,true,"TRADE",true,"Output Value which references a Trade. Value of  the KEY.TRADE.INPUT from another Test Step.",0));
	Collections.sort(parameters,BY_POSITION);
	}
	return parameters;
	}
}
