package calypsox.tk.engine;

import com.calypso.engine.Engine;
import com.calypso.tk.core.Log;
import com.calypso.tk.event.PSEvent;
import com.calypso.tk.event.PSEventTrade;
import com.calypso.tk.service.DSConnection;

/**
 * Custom engine example, logs message when trade events are processed
 */
public class CustomEngine extends Engine {

	public CustomEngine(DSConnection dsCon, String hostName, int port) {
		super(dsCon, hostName, port);
	}

	@Override
	public boolean process(PSEvent arg0) {
		if(arg0 instanceof PSEventTrade) {
			Log.system(CustomEngine.class.getName(), "Logging trade " + ((PSEventTrade)arg0).getTradeId());
		}
		return true;
	}

}
